""" Test module for handler """


def test_example():
    assert True
