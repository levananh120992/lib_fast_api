from .producer import AIOKafkaProducer

__all__ = ["AIOKafkaProducer"]
